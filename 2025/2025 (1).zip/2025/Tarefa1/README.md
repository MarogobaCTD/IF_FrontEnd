# Tarefa1: Bootstrap e TypeScript - 2025

Este trabalho foi desenvolvido como atividade na matéria TECNOLOGIA FRONT-END do curso Desenvolvimento Web e Mobile no IFSUDESTEMG.

## Informações:
Aluno: Marcelo Roberto Gomes Barbosa

Professores: LUCAS GRASSANO LATTARI e MAURICIO ARCHANJO NUNES COELHO

